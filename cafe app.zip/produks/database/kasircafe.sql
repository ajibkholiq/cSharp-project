-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Apr 2023 pada 12.34
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasircafe`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `kode` char(10) NOT NULL,
  `nama` char(30) DEFAULT NULL,
  `kategori` char(30) DEFAULT NULL,
  `harga` int(8) DEFAULT NULL,
  `deskripsi` varchar(100) DEFAULT NULL,
  `photo` char(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`kode`, `nama`, `kategori`, `harga`, `deskripsi`, `photo`) VALUES
('MM01', 'Mie Kuah Seafood', 'makanan', 35000, 'Mie kuah dengan seafood segar, sayur, dll yang dibumbui dengan rempah pilihan', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\mie kuah seafood.jpg'),
('MM02', 'Nasi Sambal Cum', 'makanan', 23000, 'Nasi hangat yang di beri sambal cumi, dengan olahan cumi serta bumbu pilihan', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\nasi cumi.jpg'),
('MM03', 'Mie Goreng', 'makanan', 16000, 'Mie goreng super lezat yang dimasak dengan bumbu pilihan dan sayuran segar', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\mie goreng.jpg'),
('MM04', 'Nasi Sate Ayam', 'makanan', 25000, 'Nasi dan sate ayam yang dibumbui dengan sambal kacang yang super lezat', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\sate.jpg'),
('MM05', 'Nasi Goreng Spesial Beef', 'makanan', 28000, 'Nasi goreng dengan tambahan daging sapi, dibumbui dengan rempah pilihan', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\nasgor spesial.jpg'),
('MM06', 'Kentang Goreng', 'makanan', 10000, 'Kentang yang di goreng dengan bumbu super lezat', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\kentang goreng.jpg'),
('MN01', 'Boba Brown Sugar', 'minuman', 11000, 'Minuman kekinian yang bertoping boba dengan brown sugar sangat segar untuk dinikmati', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\boba.jpg'),
('MN02', ' Es Coklat Spesial', 'minuman', 15000, 'Es coklat yang bertoping ice cream, taburan coklat dan susu', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\es coklat spesial.jpg'),
('MN03', 'Jus Alpukat', 'minuman', 12000, 'Minuman dengan buah alpukat segar yang diberi susu coklat', 'D:\\Semester 6\\c#\\produks\\produks\\Resources\\jus alpukat.jpg'),
('MN04', 'Es Teh Manis', 'minuman', 6000, ' Es teh manis segar yang nikmat diminum', 'D:\\Semester 6\\c#\\produks\\produks\\Resources');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan`
--

CREATE TABLE `pesan` (
  `id_transaksi` char(10) NOT NULL,
  `nama` char(30) DEFAULT NULL,
  `no_meja` int(2) DEFAULT NULL,
  `pembayaran` char(15) DEFAULT NULL,
  `tipe` char(20) DEFAULT NULL,
  `status` char(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pesan`
--

INSERT INTO `pesan` (`id_transaksi`, `nama`, `no_meja`, `pembayaran`, `tipe`, `status`) VALUES
('cf0231', 'naufal', 5, 'dana', 'makan ditempat', 'selesai'),
('deaww', 'rudi', 10, 'transfer', 'take home', 'diantar'),
('jmt1', 'epul', 1, 'bayar di tempat', 'makan ditempat', 'dipesan'),
('jmt2', 'ajib abdul', 5, 'bayar di tempat', 'makan ditempat', 'diproses'),
('mngg23', 'putri', 5, 'qris', 'take home', 'selesai'),
('sbt12', 'rei', 1, 'dana', 'makan ditempat', 'diproses');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `kode_menu` char(10) DEFAULT NULL,
  `jumlah` int(2) DEFAULT NULL,
  `id_transaksi` char(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`kode_menu`, `jumlah`, `id_transaksi`) VALUES
('MM01', 3, 'cf0231'),
('MN01', 1, 'cf0231'),
('MN03', 2, 'cf0231'),
('MM04', 2, 'deaww'),
('MN03', 2, 'deaww'),
('MM03', 2, 'jmt1'),
('MM02', 2, 'jmt1'),
('MN03', 3, 'jmt1'),
('MM05', 1, 'jmt2'),
('MN03', 1, 'jmt2'),
('MM04', 3, 'mngg23'),
('MM02', 3, 'mngg23'),
('MN01', 4, 'mngg23'),
('MM02', 2, 'sbt12'),
('MN03', 2, 'sbt12');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`kode`);

--
-- Indeks untuk tabel `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD KEY `fk_menu` (`kode_menu`),
  ADD KEY `fk_id` (`id_transaksi`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `fk_id` FOREIGN KEY (`id_transaksi`) REFERENCES `pesan` (`id_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_menu` FOREIGN KEY (`kode_menu`) REFERENCES `menu` (`kode`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
