﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace produks
{
    class dbconnection
    {
        public static MySqlConnection createConnection(string host, string user, string pass, string db)
        {
            return new MySqlConnection("datasource=" + host + ";port=3306;username=" + user + ";password=" + pass + ";database=" + db + "");
        }
        public static MySqlConnection dbcafe = createConnection("localhost", "root","", "kasircafe");

       
    }
    class query
    {
        public static bool execute(MySqlConnection db, string sql)
        {
            MySqlConnection con = db;
            MySqlCommand cm = new MySqlCommand(sql, con);
            try
            {
                con.Open();
                cm.ExecuteNonQuery();
                con.Close();
                cm.Dispose();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
                cm.Dispose();
                return false;
            }

        }
        public static DataTable CreateDataTables(MySqlConnection db, String sql)
        {
            MySqlConnection con = db;
            MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
   
}
