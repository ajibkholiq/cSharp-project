﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace produks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            start();
            getpesanan();
            lblpesan.Text = GetStatus(dbconnection.dbcafe, "dipesan");
            lblProses.Text = GetStatus(dbconnection.dbcafe, "diproses");
            lbldiantar.Text = GetStatus(dbconnection.dbcafe, "diantar");
            lblselesai.Text = GetStatus(dbconnection.dbcafe, "selesai");
        }   

        private void start()
        {
            pnlmenu.Visible = false;
        }

        private  void hidmenu()
        {
            if(pnlmenu.Visible == true) {
            pnlmenu.Visible = false;}
        }
        private void showsubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hidmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
       

        public Form activform = null;
        private void openChildForm(Form child)
        {
            if (activform != null)
                activform.Close();
            activform = child;
            activform.TopLevel = false;
            child.FormBorderStyle = FormBorderStyle.None;
            child.Dock = DockStyle.Fill;
            childform.Controls.Add(child);
            childform.Tag = child;
            child.BringToFront();
            child.Show();

        }


        #region
        //funsi - fungsi get data

        private void getpesanan()
        {
            dgvPesanan.DataSource = query.CreateDataTables(dbconnection.dbcafe, "select * from pesan ");
        }
        private void getpesanansts(string sts)
        {
            dgvPesanan.DataSource = query.CreateDataTables(dbconnection.dbcafe, "select * from pesan where status ='"+sts+"'");
        }
        public static string GetStatus(MySqlConnection db, string status)
        {
            MySqlConnection con = db;
            MySqlDataAdapter da = new MySqlDataAdapter("select count(status) from pesan where status ='" + status + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt.Rows[0][0].ToString();
        }
        private void dgvPesanan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dgvPesanan.Rows[e.RowIndex].Cells[1].Value.ToString();
            detailPesanan detail = new detailPesanan(id);
            openChildForm(detail);
        }
        private bool deletepesanan(string id)
        {
            string sql;

            sql = "delete from pesan where id= '" + id + "' and status ='Selesai'";
            return query.execute(dbconnection.dbcafe, sql);
        }

        private void cariNama()
        {
            string sql = "select * from pesan where nama like '%" + textBox1.Text + "%' or no_meja ='" + textBox1.Text + "'";
            dgvPesanan.DataSource = query.CreateDataTables(dbconnection.dbcafe,sql);
        }
        #endregion




        #region button_click
        //prosedur Klik button
        private void button2_Click(object sender, EventArgs e)
        {
            showsubmenu(pnlmenu);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cyber Tekno startup\n\nProgrammer\t:Ajib Abdul Kholiq \nUI Designer\t:Reishinta Putri A", "DEVELOPER", MessageBoxButtons.OK);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (activform != null)
                activform.Close();
            getpesanan();
        }

        private void addMenu_Click(object sender, EventArgs e)
        {
            openChildForm(new addmenu());
        }

        private void showMenu_Click(object sender, EventArgs e)
        {
            openChildForm(new listmenu());
        }
        private void btndel_Click(object sender, EventArgs e)
        {

            int jumlah = 0;
            for (int i = 0; i < dgvPesanan.Rows.Count; i++)
            {
                if (Convert.ToBoolean(dgvPesanan.Rows[i].Cells[0].EditedFormattedValue) == true && dgvPesanan.Rows[i].Cells[7].Value.ToString() == "Selesai")
                {
                    deletepesanan(dgvPesanan.Rows[i].Cells[1].Value.ToString());
                    jumlah++;
                }
            }
            MessageBox.Show("Pesanan status selesai dihapus =" + jumlah, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            getpesanan();

        }
        private void panel2_Paint(object sender, EventArgs e)
        {
            getpesanansts("Dipesan");
        }

        private void panel5_Paint(object sender, EventArgs e)
        {
            getpesanansts("Diproses");
        }

        private void panel6_Click(object sender, EventArgs e)
        {
            getpesanansts("Selesai");

        }

        private void panel4_Click(object sender, EventArgs e)
        {
            getpesanansts("Diantar");

        }
        #endregion


        private void button2_Click_1(object sender, EventArgs e)
        {
            cariNama();
            textBox1.Text = "";
        }
    }

}
