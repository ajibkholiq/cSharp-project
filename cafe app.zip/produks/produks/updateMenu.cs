﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace produks
{
    public partial class updateMenu : Form
    {
        public string kode;
        public updateMenu(string kode)
        {
            InitializeComponent();
            this.kode = kode;
            getdataUpdate();
        }

        private void updateMenu_Load(object sender, EventArgs e)
        {

        }

        private void getdataUpdate()
        {
            MySqlDataAdapter da = new MySqlDataAdapter("select * from menu where kode ='" + kode + "'", dbconnection.dbcafe);
            DataTable dt = new DataTable();
            da.Fill(dt);
            txkode.ReadOnly= true;
            txkode.Text = dt.Rows[0]["kode"].ToString();
            txnama.Text = dt.Rows[0]["nama"].ToString();
            txkategori.Text = dt.Rows[0]["kategori"].ToString();
            txharga.Text = dt.Rows[0]["harga"].ToString();
            richTextBox1.Text = dt.Rows[0]["deskripsi"].ToString();
            pictureBox1.ImageLocation = dt.Rows[0]["photo"].ToString();
            txImage.Text = dt.Rows[0]["photo"].ToString();
            txImage.ReadOnly= true;

        }

        private void update()

        {
            MySqlDataAdapter da = new MySqlDataAdapter("select * from menu where kode ='" + kode + "'", dbconnection.dbcafe);
            DataTable dt = new DataTable();
            da.Fill(dt);
            string fileName = Path.GetFileName(txImage.Text);
            string projectFilePath = Path.Combine(@"D:\Semester 6\c#\produks\produks\Resources", fileName);

            if (!File.Exists(projectFilePath))
            {
                File.Copy(txImage.Text, projectFilePath);
            }

            string sql;
            sql = "update menu set nama = '" + txnama.Text + "', ";
            sql = sql + "kategori= '" + txkategori.Text + "', ";
            sql = sql + "harga= '" + txharga.Text + "', ";
            sql = sql + "deskripsi= '" + richTextBox1.Text + "', ";
            sql = sql + "photo= '" + projectFilePath.Replace("\\", "\\\\") + "' where kode ='"+ dt.Rows[0]["kode"].ToString() + "'";

            if (query.execute(dbconnection.dbcafe, sql)) // Lihat class Funstions.cs function Execute (Tekan F12)
            {
                MessageBox.Show("Data berhasil diubah", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            update();
            Close();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            btnupload.PerformClick();
        }

        private void btnupload_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Pilih foto profil";
                openFileDialog.InitialDirectory =
                             Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                openFileDialog.Filter = "Image Files (*.png, *.jpg)|*.png;*.jpg";
                openFileDialog.Multiselect = false;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = new Bitmap(openFileDialog.FileName);
                }
                //txPath.Text = openFileDialog.SafeFileName;
                txImage.Text = openFileDialog.FileName;
            }
        }
        private bool deletemenu(string id)
        {
            string sql;

            sql = "delete from menu where kode= '" + id + "'";
            return query.execute(dbconnection.dbcafe, sql);
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            deletemenu(txkode.Text);
            MessageBox.Show("menu berhasil dihapus", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
  
        }
    }
}
