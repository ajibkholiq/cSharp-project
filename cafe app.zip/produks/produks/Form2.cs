﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace produks
{
    public partial class listmenu : Form
    {
        public listmenu()
        {
            InitializeComponent();
            getlistmenu();
        }

        private void getlistmenu()
        {
          dgvListMenu.DataSource = query.CreateDataTables(dbconnection.dbcafe, "select kode, nama , kategori, harga, deskripsi from menu");
        }

        private void dgvListMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dgvListMenu.Rows[e.RowIndex].Cells[1].Value.ToString();
            updateMenu detail = new updateMenu(id);
            detail.ShowDialog();
        }
        private bool deletemenu(string id)
        {
            string sql;

            sql = "delete from menu where kode= '" + id + "'";
            return query.execute(dbconnection.dbcafe, sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvListMenu.Rows.Count; i++)
            {
                if (Convert.ToBoolean(dgvListMenu.Rows[i].Cells[0].EditedFormattedValue) == true)
                {
                    deletemenu(dgvListMenu.Rows[i].Cells["kode"].Value.ToString());
                }
            }
            MessageBox.Show("menu berhasil dihapus", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            getlistmenu();
        }
    }
}
