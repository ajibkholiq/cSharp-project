﻿namespace produks
{
    partial class listmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(listmenu));
            this.label17 = new System.Windows.Forms.Label();
            this.dgvListMenu = new System.Windows.Forms.DataGridView();
            this.select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.kode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kategori = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.harga = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deskripsi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(59, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(122, 24);
            this.label17.TabIndex = 19;
            this.label17.Text = "Daftar Menu";
            // 
            // dgvListMenu
            // 
            this.dgvListMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListMenu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListMenu.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvListMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListMenu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.select,
            this.kode,
            this.nama,
            this.kategori,
            this.harga,
            this.deskripsi});
            this.dgvListMenu.Location = new System.Drawing.Point(63, 111);
            this.dgvListMenu.Name = "dgvListMenu";
            this.dgvListMenu.Size = new System.Drawing.Size(627, 424);
            this.dgvListMenu.TabIndex = 20;
            this.dgvListMenu.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListMenu_CellContentClick);
            // 
            // select
            // 
            this.select.FillWeight = 60.9137F;
            this.select.HeaderText = "Select";
            this.select.MinimumWidth = 15;
            this.select.Name = "select";
            // 
            // kode
            // 
            this.kode.DataPropertyName = "kode";
            this.kode.FillWeight = 107.8173F;
            this.kode.HeaderText = "Kode";
            this.kode.Name = "kode";
            // 
            // nama
            // 
            this.nama.DataPropertyName = "nama";
            this.nama.FillWeight = 107.8173F;
            this.nama.HeaderText = "Nama";
            this.nama.Name = "nama";
            // 
            // kategori
            // 
            this.kategori.DataPropertyName = "kategori";
            this.kategori.FillWeight = 107.8173F;
            this.kategori.HeaderText = "Kategori";
            this.kategori.Name = "kategori";
            // 
            // harga
            // 
            this.harga.DataPropertyName = "harga";
            this.harga.FillWeight = 107.8173F;
            this.harga.HeaderText = "Harga";
            this.harga.Name = "harga";
            // 
            // deskripsi
            // 
            this.deskripsi.DataPropertyName = "deskripsi";
            this.deskripsi.FillWeight = 107.8173F;
            this.deskripsi.HeaderText = "Deskripsi";
            this.deskripsi.Name = "deskripsi";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(583, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Delete Selected";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listmenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 574);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvListMenu);
            this.Controls.Add(this.label17);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "listmenu";
            this.Text = "Daftar menu";
            ((System.ComponentModel.ISupportInitialize)(this.dgvListMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView dgvListMenu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn select;
        private System.Windows.Forms.DataGridViewTextBoxColumn kode;
        private System.Windows.Forms.DataGridViewTextBoxColumn nama;
        private System.Windows.Forms.DataGridViewTextBoxColumn kategori;
        private System.Windows.Forms.DataGridViewTextBoxColumn harga;
        private System.Windows.Forms.DataGridViewTextBoxColumn deskripsi;
    }
}