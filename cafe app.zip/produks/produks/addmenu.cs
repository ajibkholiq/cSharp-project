﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace produks
{
    public partial class addmenu : Form
    {
        public addmenu()
        {
            InitializeComponent();
        }
        private void insert()
        {
            string sql;

            //cek duplikat npm untuk memastikan tidak ada npm yg sama 
            DataTable data = query.CreateDataTables(dbconnection.dbcafe, "select * from menu where kode = '" + txkode.Text + "'");

            //proses cek dan save data
            if (data.Rows.Count == 0)
            {
                // Jika npm tidak ada maka lakukan proses save

                /*Proses menyimpan gambar*/
                string fileName = Path.GetFileName(txImage.Text);
                string projectFilePath = Path.Combine(@"D:\Semester 6\c#\produks\produks\Resources", fileName);
                if (txImage.Text != "") {
                    if (!File.Exists(projectFilePath))
                        File.Copy(txImage.Text, projectFilePath);

                }

                /* end Proses */
                try
                {
                    sql = "insert into menu (kode, nama,kategori,harga,deskripsi,photo) values ";
                    sql = sql + "('" + txkode.Text + "', ";
                    sql = sql + " '" + txnama.Text + "', ";
                    sql = sql + " '" + txkategori.Text + "', ";
                    sql = sql + " '" + txharga.Text + "', ";
                    sql = sql + " '" + richTextBox1.Text + "', ";
                    sql = sql + " '" + projectFilePath.Replace("\\", "\\\\") + "') ";

                    if (query.execute(dbconnection.dbcafe, sql)) // Lihat class Funstions.cs function Execute (Tekan F12)
                    {
                        MessageBox.Show("Data berhasil disimpan", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                catch { }
            }
            else
            {
                //jika npm ada maka tampilkan pesan peringatan
                string mhs = data.Rows[0]["kode"].ToString();
                MessageBox.Show("kode yang dimasukan sudah terdaftar, silakan masukan NPM yang berbeda!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txkode.Focus();
            }
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            btnupload.PerformClick();
        }

        private void btnupload_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Pilih foto profil";
                openFileDialog.InitialDirectory =
                             Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                openFileDialog.Filter = "Image Files (*.png, *.jpg)|*.png;*.jpg";
                openFileDialog.Multiselect = false;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = new Bitmap(openFileDialog.FileName);
                }
                //txPath.Text = openFileDialog.SafeFileName;
                txImage.Text = openFileDialog.FileName;
            }
        }
        private void clear()
        {
            foreach (Control ctrl in panel1.Controls)
            {
                if (ctrl is TextBox || ctrl is ComboBox || ctrl is RichTextBox)
                {
                    ctrl.Text = "";
                }
            }
            richTextBox1.Text = "";
            pictureBox1.Image = null;

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            insert();
            clear();
        }

        private void addmenu_Load(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
