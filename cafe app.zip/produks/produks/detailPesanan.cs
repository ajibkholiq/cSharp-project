﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace produks
{
    public partial class detailPesanan : Form
    {
        public string kode;
        public detailPesanan(string kode)
        {
            InitializeComponent();
            this.kode = kode;
            GetDetailPesanan();
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void GetDetailPesanan()
        {
            int total = 0,jumlah, harga;
            MySqlDataAdapter da = new MySqlDataAdapter("select * from pesan where id_transaksi ='"+kode+"'", dbconnection.dbcafe);
            DataTable dt = new DataTable();
            da.Fill(dt);
            lblnama.Text= dt.Rows[0][1].ToString();
            lbltipe.Text= dt.Rows[0][4].ToString();
            lblNomeja.Text= dt.Rows[0][2].ToString();
            lblpembayaran.Text= dt.Rows[0][3].ToString();
            lblstatus.Text= dt.Rows[0][5].ToString();

            dgwmenu.DataSource = query.CreateDataTables(dbconnection.dbcafe, "select nama,kategori,jumlah,harga from menu,pesanan where menu.kode = pesanan.kode_menu and id_transaksi ='" + kode + "'");

            for (int i=0; i <dgwmenu.RowCount-1;i++)
            {
            jumlah =(int)dgwmenu.Rows[i].Cells[2].Value;
            harga = (int)dgwmenu.Rows[i].Cells[3].Value;
            total = total + (jumlah*harga);
            }
            lbltotal.Text = total.ToString();


        }
    }
}
