﻿namespace ajibperpus
{
    partial class pinjam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txIdmbr = new System.Windows.Forms.TextBox();
            this.txNama = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txAlamat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txHp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txKdBuku = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnCari = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btMbr = new System.Windows.Forms.Button();
            this.btnTamu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(582, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "Pinjam";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(90, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "ID Member";
            // 
            // txIdmbr
            // 
            this.txIdmbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txIdmbr.Location = new System.Drawing.Point(93, 123);
            this.txIdmbr.Multiline = true;
            this.txIdmbr.Name = "txIdmbr";
            this.txIdmbr.Size = new System.Drawing.Size(393, 26);
            this.txIdmbr.TabIndex = 21;
            // 
            // txNama
            // 
            this.txNama.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txNama.Location = new System.Drawing.Point(93, 179);
            this.txNama.Multiline = true;
            this.txNama.Name = "txNama";
            this.txNama.Size = new System.Drawing.Size(486, 26);
            this.txNama.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(90, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 18);
            this.label3.TabIndex = 22;
            this.label3.Text = "Nama";
            // 
            // txAlamat
            // 
            this.txAlamat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txAlamat.Location = new System.Drawing.Point(93, 233);
            this.txAlamat.Multiline = true;
            this.txAlamat.Name = "txAlamat";
            this.txAlamat.Size = new System.Drawing.Size(486, 26);
            this.txAlamat.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(90, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 18);
            this.label4.TabIndex = 24;
            this.label4.Text = "Alamat";
            // 
            // txHp
            // 
            this.txHp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txHp.Location = new System.Drawing.Point(93, 283);
            this.txHp.Multiline = true;
            this.txHp.Name = "txHp";
            this.txHp.Size = new System.Drawing.Size(486, 26);
            this.txHp.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(90, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 18);
            this.label5.TabIndex = 26;
            this.label5.Text = "No HP";
            // 
            // txKdBuku
            // 
            this.txKdBuku.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txKdBuku.Location = new System.Drawing.Point(93, 338);
            this.txKdBuku.Multiline = true;
            this.txKdBuku.Name = "txKdBuku";
            this.txKdBuku.Size = new System.Drawing.Size(486, 26);
            this.txKdBuku.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(90, 317);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 18);
            this.label8.TabIndex = 28;
            this.label8.Text = "Kode Buku";
            // 
            // btnCari
            // 
            this.btnCari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCari.Location = new System.Drawing.Point(504, 123);
            this.btnCari.Name = "btnCari";
            this.btnCari.Size = new System.Drawing.Size(75, 26);
            this.btnCari.TabIndex = 30;
            this.btnCari.Text = "Cari";
            this.btnCari.UseVisualStyleBackColor = true;
            this.btnCari.Click += new System.EventHandler(this.btnCari_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(504, 398);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 26);
            this.button4.TabIndex = 31;
            this.button4.Text = "Pinjam";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(411, 398);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 26);
            this.button5.TabIndex = 32;
            this.button5.Text = "Clear";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btMbr
            // 
            this.btMbr.BackColor = System.Drawing.Color.LimeGreen;
            this.btMbr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMbr.Location = new System.Drawing.Point(93, 50);
            this.btMbr.Name = "btMbr";
            this.btMbr.Size = new System.Drawing.Size(75, 26);
            this.btMbr.TabIndex = 34;
            this.btMbr.Text = "Member";
            this.btMbr.UseVisualStyleBackColor = false;
            this.btMbr.Click += new System.EventHandler(this.btMbr_Click);
            // 
            // btnTamu
            // 
            this.btnTamu.BackColor = System.Drawing.SystemColors.Control;
            this.btnTamu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTamu.Location = new System.Drawing.Point(186, 50);
            this.btnTamu.Name = "btnTamu";
            this.btnTamu.Size = new System.Drawing.Size(75, 26);
            this.btnTamu.TabIndex = 33;
            this.btnTamu.Text = "Tamu";
            this.btnTamu.UseVisualStyleBackColor = false;
            this.btnTamu.Click += new System.EventHandler(this.btnTamu_Click);
            // 
            // pinjam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(675, 495);
            this.Controls.Add(this.btMbr);
            this.Controls.Add(this.btnTamu);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnCari);
            this.Controls.Add(this.txKdBuku);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txHp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txAlamat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txNama);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txIdmbr);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "pinjam";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "pinjam";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txIdmbr;
        private System.Windows.Forms.TextBox txNama;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txAlamat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txHp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txKdBuku;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnCari;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btMbr;
        private System.Windows.Forms.Button btnTamu;
    }
}