﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
   
    public partial class Editbuku : Form
    {
        public string id;
        public Editbuku(string id)
        {
            InitializeComponent();
            this.id= id;
            getdata();
        }

        private void getdata()
        {
            DataTable data;
                data = query.getdata("select * from buku where kode = '" + id + "';");
                txKode.Text = data.Rows[0][0].ToString();
                txjudul.Text = data.Rows[0][1].ToString();
                rcSinopsis.Text = data.Rows[0][2].ToString();
                txpenulis.Text = data.Rows[0][3].ToString();
                txpenerbit.Text = data.Rows[0][4].ToString();
                txRak.Text = data.Rows[0][5].ToString();
                txKategori.Text = data.Rows[0][6].ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
                if (query.execute("UPDATE `buku` SET `judul` = '"+txjudul.Text+"', `sinopsis` = '"+rcSinopsis.Text+"', `penulis` = '"+txpenulis.Text+"', `penerbit` = '"+txpenerbit.Text+"', `no_rak` = '"+txRak.Text+"', `kategori` = '"+txKategori.Text+"' WHERE `buku`.`kode` = '"+id+"';")) MessageBox.Show("Berhasil diedit!!");
                Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
                if (query.execute("delete from buku where kode = '"+id+"';")) MessageBox.Show("Berhasil dihapus!!");
                Close();
        }
    }
}
