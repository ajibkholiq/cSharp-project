﻿namespace ajibperpus
{
    partial class Memberpmjmn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txcari = new System.Windows.Forms.TextBox();
            this.btnCari = new System.Windows.Forms.Button();
            this.dgvpinjam = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvpinjam)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(491, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "Peminjam - Member";
            // 
            // txcari
            // 
            this.txcari.Location = new System.Drawing.Point(45, 16);
            this.txcari.Multiline = true;
            this.txcari.Name = "txcari";
            this.txcari.Size = new System.Drawing.Size(189, 26);
            this.txcari.TabIndex = 22;
            // 
            // btnCari
            // 
            this.btnCari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCari.Location = new System.Drawing.Point(240, 16);
            this.btnCari.Name = "btnCari";
            this.btnCari.Size = new System.Drawing.Size(75, 26);
            this.btnCari.TabIndex = 31;
            this.btnCari.Text = "Cari";
            this.btnCari.UseVisualStyleBackColor = true;
            this.btnCari.Click += new System.EventHandler(this.btnCari_Click);
            // 
            // dgvpinjam
            // 
            this.dgvpinjam.AllowUserToAddRows = false;
            this.dgvpinjam.AllowUserToDeleteRows = false;
            this.dgvpinjam.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvpinjam.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvpinjam.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvpinjam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvpinjam.Location = new System.Drawing.Point(45, 68);
            this.dgvpinjam.Name = "dgvpinjam";
            this.dgvpinjam.ReadOnly = true;
            this.dgvpinjam.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvpinjam.Size = new System.Drawing.Size(585, 396);
            this.dgvpinjam.TabIndex = 32;
            this.dgvpinjam.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvpinjam_CellClick);
            // 
            // Memberpmjmn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 495);
            this.Controls.Add(this.dgvpinjam);
            this.Controls.Add(this.btnCari);
            this.Controls.Add(this.txcari);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Memberpmjmn";
            this.Text = "Memberpmjmn";
            ((System.ComponentModel.ISupportInitialize)(this.dgvpinjam)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txcari;
        private System.Windows.Forms.Button btnCari;
        private System.Windows.Forms.DataGridView dgvpinjam;
    }
}