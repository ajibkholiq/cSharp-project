﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ajibperpus
{
    internal class db
    {
        public static MySqlConnection dbconect = new MySqlConnection("datasource=localhost ;port=3306;username=root ;password=''; database=perpus_ajib ");
    }

    class validasi
    {
       public static bool isAdmin(string id,string pw)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("select password,role from users where id =" + id + ";", db.dbconect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows[0][0].ToString() == pw && dt.Rows[0][1].ToString() == "admin")
            {
                return true;
            } else  return false ;
        }

        public static bool isMember(string id,string pw)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("select password,role from users where id =" + id + ";", db.dbconect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows[0][0].ToString() == pw && dt.Rows[0][1].ToString() == "member")
            {
                return true;
            }
            else return false;
        }
    }

    class query
    {
        public static bool execute( string sql)
        {
            MySqlCommand cm = new MySqlCommand(sql, db.dbconect);
            try
            {
                db.dbconect.Open();
                cm.ExecuteNonQuery();
                db.dbconect.Close();
                cm.Dispose();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                db.dbconect.Close();
                cm.Dispose();
                return false;
            }

        }

        public static string GetStatus(string table)
        {
            if (table != "users")
            {
                MySqlDataAdapter da = new MySqlDataAdapter("select count(*) from " + table, db.dbconect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt.Rows[0][0].ToString();
            }
            else
            {
                MySqlDataAdapter da = new MySqlDataAdapter("select count(*) from " + table + " where role = 'member';", db.dbconect); 
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt.Rows[0][0].ToString();
            }
        }
        public static DataTable getAll(String table)
        {
            if (table != "users")
            {
                MySqlDataAdapter da = new MySqlDataAdapter("select kode as Kode, judul As Judul, sinopsis as Sinopsis, penulis as Penulis, penerbit as Penerbit, no_rak as Rak, kategori as Kategori  from " + table, db.dbconect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            } else
            {
                MySqlDataAdapter da = new MySqlDataAdapter("select id as ID , nama as Nama, gender as 'Jenis kelamin',alamat as Alamat, no_hp as handphone from " + table + " where role = 'member';", db.dbconect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;

            }
            
        }
        public static DataTable getdata(String sql)
        {
                MySqlDataAdapter da = new MySqlDataAdapter(sql, db.dbconect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
        }

    } 
} 
