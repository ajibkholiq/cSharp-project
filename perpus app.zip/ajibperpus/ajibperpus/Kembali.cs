﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class Kembali : Form
    {
        public string id, jns;
        public Kembali( string id, string jns)
        {
            InitializeComponent();
            this.id = id;
            this.jns = jns;
            getData();
        }

        void getData()
        {
            DataTable data;
            if (jns == "member")
            {
                data = query.getdata("select users.nama , buku.judul ,DATE_FORMAT( tgl_pinjam,'%M %d %Y'),DATE_FORMAT( tgl_kembali, '%M %d %Y') from users,peminjaman,buku where role = 'member' and users.id = peminjaman.users_id and peminjaman.kode_buku = buku.kode and peminjaman.id = '" + id+"';");
                nama.Text = data.Rows[0][0].ToString();
                judul.Text = data.Rows[0][1].ToString();
                pinjam.Text = data.Rows[0][2].ToString();
                if (data.Rows[0][3].ToString() == null)
                {
                    tglKmbl.Text = "Belum Dikembalikan";
                }
                 else
                {
                    tglKmbl.Text = data.Rows[0][3].ToString();
                }

            }else
            {
                data = query.getdata("select nama , buku.judul ,DATE_FORMAT( tgl_pinjam, '%M %d %Y'),DATE_FORMAT( tgl_kembali, '%M %d %Y') from peminjam,buku where  peminjam.kode_buku = buku.kode and nama = '" + id + "';");
                nama.Text = data.Rows[0][0].ToString();
                judul.Text = data.Rows[0][1].ToString();
                pinjam.Text = data.Rows[0][2].ToString();
                if (data.Rows[0][3].ToString() == "")
                {
                    tglKmbl.Text = "Belum Dikembalikan";
                }
                else
                {
                    tglKmbl.Text = data.Rows[0][3].ToString();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Kembali_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (jns == "member")
            {

                if (query.execute("UPDATE `peminjaman` SET `tgl_kembali` = now() WHERE `peminjaman`.`id` = '" + id + "';")) MessageBox.Show("Berhasil dikembalikan!!");

            }
            else
            {
                if (query.execute("UPDATE `peminjam` SET `tgl_kembali` = now() WHERE `nama` = '" + id + "';")) MessageBox.Show("Berhasil dikembalikan!!");
            }

            getData();
        }
    }
}
