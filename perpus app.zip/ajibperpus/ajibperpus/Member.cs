﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class Member : Form
    {
        public Member()
        {
            InitializeComponent();
            dgvmember.DataSource = query.getAll("users");
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string sql = "select id as ID , nama as Nama, gender as 'Jenis kelamin',alamat as Alamat, no_hp as handphone from users where role = 'member' and (nama like '%"+txcari.Text+ "%' or id like '%"+txcari.Text+"%');";
            dgvmember.DataSource = query.getdata(sql);
        }

        private void dgvmember_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Form T = new editMember(dgvmember.Rows[e.RowIndex].Cells[0].Value.ToString());
            T.Show();
        }
    }
}
