﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class Buku : Form
    {
        public Buku()
        {
            InitializeComponent();
            dgvbuku.DataSource = query.getAll("buku");
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string sql = "select kode as Kode, judul As Judul, sinopsis as Sinopsis, penulis as Penulis, penerbit as Penerbit, no_rak as Rak, kategori as Kategori  from buku where buku.judul like '%"+txcari.Text+ "%' or buku.kategori like '%"+txcari.Text+ "%' or buku.kode like '%"+txcari.Text+"%'";
            dgvbuku.DataSource = query.getdata(sql);
        }

        private void dgvbuku_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Form T = new Editbuku(dgvbuku.Rows[e.RowIndex].Cells[0].Value.ToString());
            T.Show();
        }
    }
}
