﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class pinjam : Form
    {
        public pinjam()
        {
            InitializeComponent();
        }
       
        private void btMbr_Click(object sender, EventArgs e)
        {
            if (txIdmbr.Enabled == false)
            {
                txIdmbr.Enabled = true;
                btMbr.BackColor = System.Drawing.Color.LimeGreen;
                btnTamu.BackColor = System.Drawing.SystemColors.Control;
                btnCari.Enabled = true;
            }
        }

        private void btnTamu_Click(object sender, EventArgs e)
        {
            if (txIdmbr.Enabled == true)
            {
                txIdmbr.Enabled = false;
                btnCari.Enabled = false;
                btnTamu.BackColor = System.Drawing.Color.LimeGreen;
                btMbr.BackColor = System.Drawing.SystemColors.Control; ;
            }
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("select nama as Nama,alamat as Alamat, no_hp as handphone from users where id ="+txIdmbr.Text+";", db.dbconect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                txNama.Text = dt.Rows[0][0].ToString();
                txAlamat.Text = dt.Rows[0][1].ToString();
                txHp.Text = dt.Rows[0][2].ToString();
            }else
            {
                MessageBox.Show("Data Tidak Ditemukan");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear()
        {
            txNama.Text = "";
            txAlamat.Text = "";
            txHp.Text = "";
            txIdmbr.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txIdmbr.Enabled == true)
            {
                bool result = query.execute("insert into peminjaman (kode_buku, users_id,jumlah,tgl_pinjam) value ('" + txKdBuku.Text + "','" + txIdmbr.Text + "', 1 , now());");

                if (result) MessageBox.Show("Berhasil"); else MessageBox.Show("Gagal");
            } else
            {
                bool result = query.execute("insert into peminjam value ('"+txNama.Text+ "','"+txAlamat.Text+ "','"+txHp.Text+"','" + txKdBuku.Text + "', now(), null );");

                if (result) MessageBox.Show("Berhasil"); else MessageBox.Show("Gagal");
            }

            clear();
            
        }
    }
}
