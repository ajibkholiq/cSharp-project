﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;
using System.Xml.Linq;

namespace ajibperpus
{
    public partial class editMember : Form
    {
        string id;
        public editMember(string id)
        {
            InitializeComponent();
            this.id = id;
            DataTable data = query.getdata("select * from users where role = 'member'");
            txIdmbr.Text = data.Rows[0][0].ToString();
            txNama.Text = data.Rows[0][1].ToString();
            password.Text = data.Rows[0][2].ToString();
            cbJenkel.Text = data.Rows[0][3].ToString();
            txAlamat.Text = data.Rows[0][4].ToString();
            txHp.Text = data.Rows[0][5].ToString();
        }

        private void editMember_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ( query.execute("UPDATE `users` SET `nama` = '"+txNama.Text+"', `password` = '"+password.Text+"', `gender` = '"+cbJenkel.Text+"', `alamat` = '"+txAlamat.Text+"', `no_hp` = '"+txHp.Text+"' WHERE `users`.`id` = '"+id+"';")) MessageBox.Show("Berhasil diEdit!!");
            Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if( query.execute( "delete from users where id = '"+id+"'")) MessageBox.Show("Berhasil diHapus!!");
            Close();
        }
    }
}
