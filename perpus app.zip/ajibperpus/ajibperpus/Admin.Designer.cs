﻿using System.Drawing;

namespace ajibperpus
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sidepnl = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.btClose = new System.Windows.Forms.Button();
            this.pnlmember = new System.Windows.Forms.Panel();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.btAddmbr = new System.Windows.Forms.Button();
            this.btListmbr = new System.Windows.Forms.Button();
            this.pnlbtmmbr = new System.Windows.Forms.Panel();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.btnmbrpnl = new System.Windows.Forms.Button();
            this.pnlBuku = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btAddbk = new System.Windows.Forms.Button();
            this.btnlistbk = new System.Windows.Forms.Button();
            this.pnlbtbk = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnBuku = new System.Windows.Forms.Button();
            this.pnlpinjaman = new System.Windows.Forms.Panel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.btpnjmnGuest = new System.Windows.Forms.Button();
            this.btmbrpnjmn = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pnlbt1 = new System.Windows.Forms.Panel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.btnpinjamam = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.btnPinjam = new System.Windows.Forms.Button();
            this.btDasbord = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.titlepnl = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.headerpnl = new System.Windows.Forms.Panel();
            this.role = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.mainpnl = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lblbk = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblguest = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblmbr = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.sidepnl.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            this.pnlmember.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.pnlbtmmbr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.pnlBuku.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlbtbk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.pnlpinjaman.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.pnlbt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel7.SuspendLayout();
            this.titlepnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.headerpnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.mainpnl.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // sidepnl
            // 
            this.sidepnl.AutoScroll = true;
            this.sidepnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(51)))), ((int)(((byte)(99)))));
            this.sidepnl.Controls.Add(this.panel1);
            this.sidepnl.Controls.Add(this.pnlmember);
            this.sidepnl.Controls.Add(this.pnlbtmmbr);
            this.sidepnl.Controls.Add(this.pnlBuku);
            this.sidepnl.Controls.Add(this.pnlbtbk);
            this.sidepnl.Controls.Add(this.pnlpinjaman);
            this.sidepnl.Controls.Add(this.pictureBox7);
            this.sidepnl.Controls.Add(this.pnlbt1);
            this.sidepnl.Controls.Add(this.pictureBox6);
            this.sidepnl.Controls.Add(this.btnPinjam);
            this.sidepnl.Controls.Add(this.btDasbord);
            this.sidepnl.Controls.Add(this.panel7);
            this.sidepnl.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepnl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sidepnl.Location = new System.Drawing.Point(0, 0);
            this.sidepnl.MaximumSize = new System.Drawing.Size(260, 550);
            this.sidepnl.MinimumSize = new System.Drawing.Size(48, 550);
            this.sidepnl.Name = "sidepnl";
            this.sidepnl.Size = new System.Drawing.Size(260, 550);
            this.sidepnl.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox17);
            this.panel1.Controls.Add(this.btClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 548);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(243, 48);
            this.panel1.TabIndex = 24;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::ajibperpus.Properties.Resources.Vector_7;
            this.pictureBox17.Location = new System.Drawing.Point(8, 6);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox17.Size = new System.Drawing.Size(28, 26);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 17;
            this.pictureBox17.TabStop = false;
            // 
            // btClose
            // 
            this.btClose.FlatAppearance.BorderSize = 0;
            this.btClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClose.Location = new System.Drawing.Point(0, 0);
            this.btClose.Name = "btClose";
            this.btClose.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btClose.Size = new System.Drawing.Size(259, 45);
            this.btClose.TabIndex = 19;
            this.btClose.Text = "Keluar";
            this.btClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // pnlmember
            // 
            this.pnlmember.Controls.Add(this.pictureBox15);
            this.pnlmember.Controls.Add(this.pictureBox16);
            this.pnlmember.Controls.Add(this.btAddmbr);
            this.pnlmember.Controls.Add(this.btListmbr);
            this.pnlmember.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlmember.Location = new System.Drawing.Point(0, 462);
            this.pnlmember.Name = "pnlmember";
            this.pnlmember.Size = new System.Drawing.Size(243, 86);
            this.pnlmember.TabIndex = 23;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::ajibperpus.Properties.Resources.Vector_51;
            this.pictureBox15.Location = new System.Drawing.Point(38, 50);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox15.Size = new System.Drawing.Size(28, 26);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 18;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::ajibperpus.Properties.Resources.Vector_61;
            this.pictureBox16.Location = new System.Drawing.Point(38, 9);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox16.Size = new System.Drawing.Size(28, 26);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 17;
            this.pictureBox16.TabStop = false;
            // 
            // btAddmbr
            // 
            this.btAddmbr.FlatAppearance.BorderSize = 0;
            this.btAddmbr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAddmbr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAddmbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAddmbr.Location = new System.Drawing.Point(0, 41);
            this.btAddmbr.Name = "btAddmbr";
            this.btAddmbr.Padding = new System.Windows.Forms.Padding(65, 0, 0, 0);
            this.btAddmbr.Size = new System.Drawing.Size(260, 45);
            this.btAddmbr.TabIndex = 1;
            this.btAddmbr.Text = "Tambah";
            this.btAddmbr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAddmbr.UseVisualStyleBackColor = true;
            this.btAddmbr.Click += new System.EventHandler(this.btAddmbr_Click);
            // 
            // btListmbr
            // 
            this.btListmbr.FlatAppearance.BorderSize = 0;
            this.btListmbr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btListmbr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btListmbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btListmbr.Location = new System.Drawing.Point(2, -1);
            this.btListmbr.Name = "btListmbr";
            this.btListmbr.Padding = new System.Windows.Forms.Padding(65, 0, 0, 0);
            this.btListmbr.Size = new System.Drawing.Size(258, 45);
            this.btListmbr.TabIndex = 0;
            this.btListmbr.Text = "Daftar Member";
            this.btListmbr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btListmbr.UseVisualStyleBackColor = true;
            this.btListmbr.Click += new System.EventHandler(this.btListmbr_Click);
            // 
            // pnlbtmmbr
            // 
            this.pnlbtmmbr.Controls.Add(this.pictureBox18);
            this.pnlbtmmbr.Controls.Add(this.btnmbrpnl);
            this.pnlbtmmbr.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlbtmmbr.Location = new System.Drawing.Point(0, 414);
            this.pnlbtmmbr.Name = "pnlbtmmbr";
            this.pnlbtmmbr.Size = new System.Drawing.Size(243, 48);
            this.pnlbtmmbr.TabIndex = 22;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::ajibperpus.Properties.Resources.Vector_2;
            this.pictureBox18.Location = new System.Drawing.Point(8, 6);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox18.Size = new System.Drawing.Size(28, 26);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 17;
            this.pictureBox18.TabStop = false;
            // 
            // btnmbrpnl
            // 
            this.btnmbrpnl.FlatAppearance.BorderSize = 0;
            this.btnmbrpnl.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnmbrpnl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmbrpnl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmbrpnl.Location = new System.Drawing.Point(0, 0);
            this.btnmbrpnl.Name = "btnmbrpnl";
            this.btnmbrpnl.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnmbrpnl.Size = new System.Drawing.Size(259, 45);
            this.btnmbrpnl.TabIndex = 19;
            this.btnmbrpnl.Text = "Member";
            this.btnmbrpnl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnmbrpnl.UseVisualStyleBackColor = true;
            this.btnmbrpnl.Click += new System.EventHandler(this.btnmbrpnl_Click);
            // 
            // pnlBuku
            // 
            this.pnlBuku.Controls.Add(this.pictureBox1);
            this.pnlBuku.Controls.Add(this.pictureBox2);
            this.pnlBuku.Controls.Add(this.btAddbk);
            this.pnlBuku.Controls.Add(this.btnlistbk);
            this.pnlBuku.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBuku.Location = new System.Drawing.Point(0, 328);
            this.pnlBuku.Name = "pnlBuku";
            this.pnlBuku.Size = new System.Drawing.Size(243, 86);
            this.pnlBuku.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ajibperpus.Properties.Resources.Vector_51;
            this.pictureBox1.Location = new System.Drawing.Point(38, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox1.Size = new System.Drawing.Size(28, 26);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ajibperpus.Properties.Resources.Vector_61;
            this.pictureBox2.Location = new System.Drawing.Point(38, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox2.Size = new System.Drawing.Size(28, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // btAddbk
            // 
            this.btAddbk.FlatAppearance.BorderSize = 0;
            this.btAddbk.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAddbk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAddbk.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAddbk.Location = new System.Drawing.Point(0, 41);
            this.btAddbk.Name = "btAddbk";
            this.btAddbk.Padding = new System.Windows.Forms.Padding(65, 0, 0, 0);
            this.btAddbk.Size = new System.Drawing.Size(260, 45);
            this.btAddbk.TabIndex = 1;
            this.btAddbk.Text = "Tambah";
            this.btAddbk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAddbk.UseVisualStyleBackColor = true;
            this.btAddbk.Click += new System.EventHandler(this.btAddbk_Click);
            // 
            // btnlistbk
            // 
            this.btnlistbk.FlatAppearance.BorderSize = 0;
            this.btnlistbk.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnlistbk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlistbk.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlistbk.Location = new System.Drawing.Point(2, -1);
            this.btnlistbk.Name = "btnlistbk";
            this.btnlistbk.Padding = new System.Windows.Forms.Padding(65, 0, 0, 0);
            this.btnlistbk.Size = new System.Drawing.Size(258, 45);
            this.btnlistbk.TabIndex = 0;
            this.btnlistbk.Text = "Daftar Buku";
            this.btnlistbk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlistbk.UseVisualStyleBackColor = true;
            this.btnlistbk.Click += new System.EventHandler(this.btnlistbk_Click);
            // 
            // pnlbtbk
            // 
            this.pnlbtbk.Controls.Add(this.pictureBox3);
            this.pnlbtbk.Controls.Add(this.btnBuku);
            this.pnlbtbk.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlbtbk.Location = new System.Drawing.Point(0, 280);
            this.pnlbtbk.Name = "pnlbtbk";
            this.pnlbtbk.Size = new System.Drawing.Size(243, 48);
            this.pnlbtbk.TabIndex = 21;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ajibperpus.Properties.Resources.Vector_41;
            this.pictureBox3.Location = new System.Drawing.Point(8, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox3.Size = new System.Drawing.Size(28, 26);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // btnBuku
            // 
            this.btnBuku.FlatAppearance.BorderSize = 0;
            this.btnBuku.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBuku.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuku.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuku.Location = new System.Drawing.Point(0, 0);
            this.btnBuku.Name = "btnBuku";
            this.btnBuku.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnBuku.Size = new System.Drawing.Size(259, 45);
            this.btnBuku.TabIndex = 19;
            this.btnBuku.Text = "Buku";
            this.btnBuku.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuku.UseVisualStyleBackColor = true;
            this.btnBuku.Click += new System.EventHandler(this.btnBuku_Click);
            // 
            // pnlpinjaman
            // 
            this.pnlpinjaman.Controls.Add(this.pictureBox13);
            this.pnlpinjaman.Controls.Add(this.pictureBox12);
            this.pnlpinjaman.Controls.Add(this.btpnjmnGuest);
            this.pnlpinjaman.Controls.Add(this.btmbrpnjmn);
            this.pnlpinjaman.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlpinjaman.Location = new System.Drawing.Point(0, 193);
            this.pnlpinjaman.Name = "pnlpinjaman";
            this.pnlpinjaman.Size = new System.Drawing.Size(243, 87);
            this.pnlpinjaman.TabIndex = 13;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ajibperpus.Properties.Resources.Vector_2;
            this.pictureBox13.Location = new System.Drawing.Point(38, 10);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox13.Size = new System.Drawing.Size(28, 26);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 13;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ajibperpus.Properties.Resources.Vector_2;
            this.pictureBox12.Location = new System.Drawing.Point(37, 51);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox12.Size = new System.Drawing.Size(28, 26);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 14;
            this.pictureBox12.TabStop = false;
            // 
            // btpnjmnGuest
            // 
            this.btpnjmnGuest.FlatAppearance.BorderSize = 0;
            this.btpnjmnGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btpnjmnGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btpnjmnGuest.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btpnjmnGuest.Location = new System.Drawing.Point(0, 42);
            this.btpnjmnGuest.Name = "btpnjmnGuest";
            this.btpnjmnGuest.Padding = new System.Windows.Forms.Padding(65, 0, 0, 0);
            this.btpnjmnGuest.Size = new System.Drawing.Size(248, 45);
            this.btpnjmnGuest.TabIndex = 16;
            this.btpnjmnGuest.Text = "Tamu";
            this.btpnjmnGuest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btpnjmnGuest.UseVisualStyleBackColor = true;
            this.btpnjmnGuest.Click += new System.EventHandler(this.btpnjmnGuest_Click);
            // 
            // btmbrpnjmn
            // 
            this.btmbrpnjmn.Dock = System.Windows.Forms.DockStyle.Top;
            this.btmbrpnjmn.FlatAppearance.BorderSize = 0;
            this.btmbrpnjmn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btmbrpnjmn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmbrpnjmn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmbrpnjmn.Location = new System.Drawing.Point(0, 0);
            this.btmbrpnjmn.Name = "btmbrpnjmn";
            this.btmbrpnjmn.Padding = new System.Windows.Forms.Padding(65, 0, 0, 0);
            this.btmbrpnjmn.Size = new System.Drawing.Size(243, 45);
            this.btmbrpnjmn.TabIndex = 15;
            this.btmbrpnjmn.Text = "Member";
            this.btmbrpnjmn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmbrpnjmn.UseVisualStyleBackColor = true;
            this.btmbrpnjmn.Click += new System.EventHandler(this.btmbrpnjmn_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ajibperpus.Properties.Resources.Vector_1;
            this.pictureBox7.Location = new System.Drawing.Point(8, 106);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox7.Size = new System.Drawing.Size(28, 26);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pnlbt1
            // 
            this.pnlbt1.Controls.Add(this.pictureBox10);
            this.pnlbt1.Controls.Add(this.btnpinjamam);
            this.pnlbt1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlbt1.Location = new System.Drawing.Point(0, 145);
            this.pnlbt1.Name = "pnlbt1";
            this.pnlbt1.Size = new System.Drawing.Size(243, 48);
            this.pnlbt1.TabIndex = 20;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ajibperpus.Properties.Resources.Vector_31;
            this.pictureBox10.Location = new System.Drawing.Point(8, 9);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox10.Size = new System.Drawing.Size(28, 26);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 17;
            this.pictureBox10.TabStop = false;
            // 
            // btnpinjamam
            // 
            this.btnpinjamam.FlatAppearance.BorderSize = 0;
            this.btnpinjamam.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnpinjamam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpinjamam.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpinjamam.Location = new System.Drawing.Point(0, 0);
            this.btnpinjamam.Name = "btnpinjamam";
            this.btnpinjamam.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnpinjamam.Size = new System.Drawing.Size(259, 45);
            this.btnpinjamam.TabIndex = 19;
            this.btnpinjamam.Text = "Pinjaman";
            this.btnpinjamam.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnpinjamam.UseVisualStyleBackColor = true;
            this.btnpinjamam.Click += new System.EventHandler(this.btnpinjamam_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ajibperpus.Properties.Resources.Vector;
            this.pictureBox6.Location = new System.Drawing.Point(8, 63);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox6.Size = new System.Drawing.Size(28, 26);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            // 
            // btnPinjam
            // 
            this.btnPinjam.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPinjam.FlatAppearance.BorderSize = 0;
            this.btnPinjam.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPinjam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPinjam.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPinjam.Location = new System.Drawing.Point(0, 100);
            this.btnPinjam.Name = "btnPinjam";
            this.btnPinjam.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnPinjam.Size = new System.Drawing.Size(243, 45);
            this.btnPinjam.TabIndex = 3;
            this.btnPinjam.Text = "Pinjam";
            this.btnPinjam.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPinjam.UseVisualStyleBackColor = true;
            this.btnPinjam.Click += new System.EventHandler(this.btnPinjam_Click);
            // 
            // btDasbord
            // 
            this.btDasbord.Dock = System.Windows.Forms.DockStyle.Top;
            this.btDasbord.FlatAppearance.BorderSize = 0;
            this.btDasbord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btDasbord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDasbord.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDasbord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btDasbord.Location = new System.Drawing.Point(0, 57);
            this.btDasbord.Name = "btDasbord";
            this.btDasbord.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btDasbord.Size = new System.Drawing.Size(243, 43);
            this.btDasbord.TabIndex = 1;
            this.btDasbord.Text = "Dashboard";
            this.btDasbord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btDasbord.UseVisualStyleBackColor = true;
            this.btDasbord.Click += new System.EventHandler(this.btDasbord_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.titlepnl);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(243, 57);
            this.panel7.TabIndex = 0;
            // 
            // titlepnl
            // 
            this.titlepnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(39)))), ((int)(((byte)(48)))));
            this.titlepnl.Controls.Add(this.label1);
            this.titlepnl.Controls.Add(this.pictureBox4);
            this.titlepnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepnl.Location = new System.Drawing.Point(0, 0);
            this.titlepnl.Name = "titlepnl";
            this.titlepnl.Size = new System.Drawing.Size(243, 55);
            this.titlepnl.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Perpustakaan";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ajibperpus.Properties.Resources.um_removebg_preview;
            this.pictureBox4.Location = new System.Drawing.Point(3, 5);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(39, 39);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // headerpnl
            // 
            this.headerpnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(39)))), ((int)(((byte)(48)))));
            this.headerpnl.Controls.Add(this.role);
            this.headerpnl.Controls.Add(this.pictureBox11);
            this.headerpnl.Controls.Add(this.pictureBox5);
            this.headerpnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpnl.Location = new System.Drawing.Point(260, 0);
            this.headerpnl.Name = "headerpnl";
            this.headerpnl.Padding = new System.Windows.Forms.Padding(5);
            this.headerpnl.Size = new System.Drawing.Size(675, 55);
            this.headerpnl.TabIndex = 2;
            // 
            // role
            // 
            this.role.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.role.AutoSize = true;
            this.role.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.role.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.role.Location = new System.Drawing.Point(593, 17);
            this.role.Name = "role";
            this.role.Size = new System.Drawing.Size(59, 20);
            this.role.TabIndex = 14;
            this.role.Text = "Admin";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox11.Image = global::ajibperpus.Properties.Resources.profil;
            this.pictureBox11.Location = new System.Drawing.Point(546, 9);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Padding = new System.Windows.Forms.Padding(10);
            this.pictureBox11.Size = new System.Drawing.Size(41, 36);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 13;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Image = global::ajibperpus.Properties.Resources.Vector1;
            this.pictureBox5.Location = new System.Drawing.Point(6, 9);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Padding = new System.Windows.Forms.Padding(10);
            this.pictureBox5.Size = new System.Drawing.Size(41, 36);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // mainpnl
            // 
            this.mainpnl.Controls.Add(this.panel4);
            this.mainpnl.Controls.Add(this.panel3);
            this.mainpnl.Controls.Add(this.label2);
            this.mainpnl.Controls.Add(this.panel2);
            this.mainpnl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainpnl.Location = new System.Drawing.Point(260, 55);
            this.mainpnl.Name = "mainpnl";
            this.mainpnl.Size = new System.Drawing.Size(675, 495);
            this.mainpnl.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.lblbk);
            this.panel4.Controls.Add(this.pictureBox14);
            this.panel4.Location = new System.Drawing.Point(73, 312);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(541, 87);
            this.panel4.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(111, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 18);
            this.label7.TabIndex = 22;
            this.label7.Text = "Buku";
            // 
            // lblbk
            // 
            this.lblbk.AutoSize = true;
            this.lblbk.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbk.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblbk.Location = new System.Drawing.Point(109, 41);
            this.lblbk.Name = "lblbk";
            this.lblbk.Size = new System.Drawing.Size(117, 25);
            this.lblbk.TabIndex = 21;
            this.lblbk.Text = "Dashboard";
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::ajibperpus.Properties.Resources.Frame_83;
            this.pictureBox14.Location = new System.Drawing.Point(12, 10);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox14.Size = new System.Drawing.Size(79, 68);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 0;
            this.pictureBox14.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.lblguest);
            this.panel3.Controls.Add(this.pictureBox9);
            this.panel3.Location = new System.Drawing.Point(73, 192);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(541, 87);
            this.panel3.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(111, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 18);
            this.label4.TabIndex = 20;
            this.label4.Text = "Pengunjung";
            // 
            // lblguest
            // 
            this.lblguest.AutoSize = true;
            this.lblguest.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblguest.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblguest.Location = new System.Drawing.Point(109, 45);
            this.lblguest.Name = "lblguest";
            this.lblguest.Size = new System.Drawing.Size(117, 25);
            this.lblguest.TabIndex = 19;
            this.lblguest.Text = "Dashboard";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ajibperpus.Properties.Resources.Frame_84;
            this.pictureBox9.Location = new System.Drawing.Point(12, 10);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(79, 68);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(562, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 18);
            this.label2.TabIndex = 15;
            this.label2.Text = "Dashboard";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.lblmbr);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Location = new System.Drawing.Point(73, 75);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(541, 87);
            this.panel2.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(111, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "Member";
            // 
            // lblmbr
            // 
            this.lblmbr.AutoSize = true;
            this.lblmbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmbr.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblmbr.Location = new System.Drawing.Point(109, 45);
            this.lblmbr.Name = "lblmbr";
            this.lblmbr.Size = new System.Drawing.Size(117, 25);
            this.lblmbr.TabIndex = 16;
            this.lblmbr.Text = "Dashboard";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ajibperpus.Properties.Resources.Frame_84;
            this.pictureBox8.Location = new System.Drawing.Point(12, 10);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(79, 68);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(935, 550);
            this.Controls.Add(this.mainpnl);
            this.Controls.Add(this.headerpnl);
            this.Controls.Add(this.sidepnl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.sidepnl.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            this.pnlmember.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.pnlbtmmbr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.pnlBuku.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlbtbk.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.pnlpinjaman.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.pnlbt1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel7.ResumeLayout(false);
            this.titlepnl.ResumeLayout(false);
            this.titlepnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.headerpnl.ResumeLayout(false);
            this.headerpnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.mainpnl.ResumeLayout(false);
            this.mainpnl.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel sidepnl;
        private System.Windows.Forms.Panel pnlpinjaman;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnPinjam;
        private System.Windows.Forms.Button btDasbord;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel headerpnl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btpnjmnGuest;
        private System.Windows.Forms.Button btmbrpnjmn;
        private System.Windows.Forms.Panel titlepnl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel mainpnl;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label role;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button btnpinjamam;
        private System.Windows.Forms.Panel pnlBuku;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Button btAddbk;
        private System.Windows.Forms.Button btnlistbk;
        private System.Windows.Forms.Panel pnlbt1;
        private System.Windows.Forms.Panel pnlbtmmbr;
        private System.Windows.Forms.Button btnmbrpnl;
        private System.Windows.Forms.Panel pnlbtbk;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnBuku;
        private System.Windows.Forms.Panel pnlmember;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Button btAddmbr;
        private System.Windows.Forms.Button btListmbr;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Button btClose;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblguest;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblmbr;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblbk;
    }
}