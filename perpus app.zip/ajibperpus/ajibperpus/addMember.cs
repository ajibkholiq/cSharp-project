﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class addMember : Form
    {
        public addMember()
        {
            InitializeComponent();
        }
           
    private void button4_Click(object sender, EventArgs e)
        {
            string sql = "insert into users value ('" + txIdmbr.Text + "','" + txNama.Text + "','" + password + "','" + cbJenkel.Text + "','" + txAlamat.Text + "','" + txHp.Text + "','member');";
            if (!query.execute(sql)) MessageBox.Show("Gagal Disimpan");
            txIdmbr.Text = "";
            txNama.Text = "";
            txAlamat.Text = "";
            cbJenkel.Text = "";
            password.Text = "";
        }
    }
}
