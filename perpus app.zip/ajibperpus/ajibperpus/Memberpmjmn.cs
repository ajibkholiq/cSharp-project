﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class Memberpmjmn : Form
    {
        public Memberpmjmn()
        {
            InitializeComponent();
            string sql = " select peminjaman.id, users.id as 'ID Member', users.nama as Nama ,buku.judul as Buku ,buku.penulis as Penulis, buku.kategori as Kategori,buku.no_rak As Rak, peminjaman.tgl_pinjam As 'Pinjam', peminjaman.tgl_kembali as Kembali  from users, buku, peminjaman where users.id = peminjaman.users_id and peminjaman.kode_buku = buku.kode  order by tgl_pinjam desc;";
            dgvpinjam.DataSource = query.getdata(sql);
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string sql = " select peminjaman.id,users.id as 'ID Member', users.nama as Nama ,buku.judul as Buku ,buku.penulis as Penulis, buku.kategori as Kategori,buku.no_rak As Rak, peminjaman.tgl_pinjam As 'Pinjam', peminjaman.tgl_kembali as Kembali  from users, buku, peminjaman where users.id = peminjaman.users_id and peminjaman.kode_buku = buku.kode";
                   sql += " and (users.nama like '%"+txcari.Text+"%' or buku.judul like '%"+txcari.Text+ "%' or buku.kategori like '%"+txcari.Text+ "%' or buku.kode like '%"+txcari.Text+"%') order by tgl_pinjam desc;";
            dgvpinjam.DataSource = query.getdata(sql);

        }

        private void dgvpinjam_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Form T = new Kembali(dgvpinjam.Rows[e.RowIndex].Cells[0].Value.ToString(), "member");
           T.Show();
        }
    }
}
