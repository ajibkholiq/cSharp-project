﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ajibperpus
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
            start();
        }

        private void start()
        {
            pnlBuku.Visible = false;
            pnlpinjaman.Visible = false;
            pnlmember.Visible = false;
            lblbk.Text = query.GetStatus("buku");
            lblguest.Text = query.GetStatus("peminjam");
            lblmbr.Text = query.GetStatus("users");
        }
        private void hidmenu()
        {
            
            if (pnlBuku.Visible == true)
            {
                pnlBuku.Visible = false;
            }
            if (pnlpinjaman.Visible == true)
            {
                pnlpinjaman.Visible = false;
            }
            if (pnlmember.Visible == true)
            {
                pnlmember.Visible = false;
            }

        }
        private void showsubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hidmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }
        public Form activform = null;
        public void openChildForm(Form child)
        {
            if (activform != null)
                activform.Close();
            activform = child;
            activform.TopLevel = false;
            child.FormBorderStyle = FormBorderStyle.None;
            child.Dock = DockStyle.Fill;
            mainpnl.Controls.Add(child);
            mainpnl.Tag = child;
            child.BringToFront();
            child.Show();

        }
        private void sideTogle()
        {
            if (sidepnl.Size.Width > 55)
            {
                sidepnl.Size = new System.Drawing.Size(48, 550);
                pictureBox12.Location = new System.Drawing.Point(8, 51);
                pictureBox13.Location = new System.Drawing.Point(8, 10);
                pictureBox1.Location = new System.Drawing.Point(8, 50);
                pictureBox2.Location = new System.Drawing.Point(8, 9);
                pictureBox15.Location = new System.Drawing.Point(8, 50);
                pictureBox16.Location = new System.Drawing.Point(8, 9);

            }
            else
            {
                sidepnl.Size = new System.Drawing.Size(260, 550);
                pictureBox1.Location = new System.Drawing.Point(38, 50);
                pictureBox2.Location = new System.Drawing.Point(38, 9);
                pictureBox15.Location = new System.Drawing.Point(38, 50);
                pictureBox16.Location = new System.Drawing.Point(38, 9);
                pictureBox12.Location = new System.Drawing.Point(38, 51);
                pictureBox13.Location = new System.Drawing.Point(38, 10);
            }
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            sideTogle();
        }

        private void btnPinjam_Click(object sender, EventArgs e)
        {
            openChildForm(new pinjam());
        }

        private void btnpinjamam_Click(object sender, EventArgs e)
        {
            showsubmenu(pnlpinjaman);
            if (sidepnl.Size.Width < 50)
            {
                sideTogle();
            }
        }

        private void btnBuku_Click(object sender, EventArgs e)
        {
            showsubmenu(pnlBuku);
            if (sidepnl.Size.Width <= 50)
            {
                sideTogle();
            }
        }

        private void btnmbrpnl_Click(object sender, EventArgs e)
        {
            showsubmenu(pnlmember);
            if (sidepnl.Size.Width <= 50)
            {
                sideTogle();
            }
        }

        private void btmbrpnjmn_Click(object sender, EventArgs e)
        {
            openChildForm(new Memberpmjmn());
        }

        private void btpnjmnGuest_Click(object sender, EventArgs e)
        {
            openChildForm(new tamupnjmn());
        }

        private void btnlistbk_Click(object sender, EventArgs e)
        {
            openChildForm(new Buku());
        }

        private void btListmbr_Click(object sender, EventArgs e)
        {
            openChildForm(new Member());
        }

        private void btDasbord_Click(object sender, EventArgs e)
        {
            if (activform != null)
                activform.Close();

            lblbk.Text = query.GetStatus("buku");
            lblguest.Text = query.GetStatus("peminjam");
            lblmbr.Text = query.GetStatus("users");
        }
        private void btAddbk_Click(object sender, EventArgs e)
        {
            openChildForm(new AddBuku());

        }

        private void btAddmbr_Click(object sender, EventArgs e)
        {
            openChildForm(new addMember());
        }
    }
}
