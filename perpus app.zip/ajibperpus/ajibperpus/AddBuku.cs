﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace ajibperpus
{
    public partial class AddBuku : Form
    {
      
        public AddBuku()
        {
            InitializeComponent();
           
        }
        public string img;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Pilih foto profil";
                openFileDialog.InitialDirectory =
                Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                openFileDialog.Filter = "Image Files (*.png, *.jpg)|*.png;*.jpg";
                openFileDialog.Multiselect = false;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = new Bitmap(openFileDialog.FileName);
                }
                //txPath.Text = openFileDialog.SafeFileName;
                img = openFileDialog.FileName;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sql = " insert into buku value ('" + txKode.Text + "','" + txjudul.Text + "','" + rcSinopsis.Text + "','" + txpenulis.Text + "','" + txpenerbit.Text + "','" + txRak.Text + "','" + txKategori.Text + "','1',null);";
           if( !query.execute(sql)) MessageBox.Show("Buku Gagal Ditambahkan") ;
        }

        private void start()
        {
          
        }
    }
}
